class Config(object):
    SQLALCHEMY_DATABASE_URI ="sqlite:///passwordmanager.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    SECRET_KEY = "mysupersecretkey1234567890!@#$%^&*()"
    
    
    CACHE_TYPE = 'SimpleCache'
    CACHE_DEFAULT_TIMEOUT = 300
    
    MAIL_SERVER="smtp.gmail.com"
    MAIL_PORT=587
    MAIL_USE_TLS=True
    MAIL_USE_SSL = False
    MAIL_USERNAME="iphone.store.apple.pl@gmail.com"
    MAIL_PASSWORD="yove adow ovfi nouo"
    MAIL_DEFAULT_SENDER=("Password Manager", "iphone.store.apple.pl@gmail.com")
    
    LOGIN_VIEW = "auth.login"
    LOGIN_MESSAGE = "You don't have permission"